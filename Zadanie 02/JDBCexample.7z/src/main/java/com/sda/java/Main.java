package com.sda.java;

import com.sda.java.dao.EmployeeDAO;
import com.sda.java.dto.Employee;

import java.util.List;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Podaj login: ");
		String login = scanner.next();
		System.out.print("Podaj hasło: ");
		String password = scanner.next();
		List<Employee> result = new EmployeeDAO(login, password).getAll();
		result.forEach(employee -> System.out.println(employee));
	}
}
